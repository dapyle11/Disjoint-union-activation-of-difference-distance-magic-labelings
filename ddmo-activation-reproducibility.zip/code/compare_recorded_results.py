#!/usr/bin/env python3
"""Compare locally regenerated JSON with the package's recorded results."""
import json
from pathlib import Path
root = Path(__file__).resolve().parent.parent
for expected in sorted((root / 'results').glob('*.json')):
    generated = root / 'code' / expected.name
    assert generated.exists(), f'Run the corresponding checker first: {generated.name}'
    assert json.loads(generated.read_text()) == json.loads(expected.read_text()), expected.name
    print('MATCH', expected.name)
