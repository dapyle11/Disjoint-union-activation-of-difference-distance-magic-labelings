#!/usr/bin/env python3
"""Exact classification for six vertices, complements of maximum degree two.
A switching-class test for an injective positive integer null labeling is exact:
K=ker S must not lie in any x_i=0 or x_i=+/-x_j hyperplane. A rational generic
vector then has distinct nonzero absolute entries, and vertex switching makes
it positive. Fixing signs on a spanning tree enumerates all switching classes.
"""
from itertools import combinations, product, permutations
from fractions import Fraction
from collections import Counter
import json
from pathlib import Path

N=6
TYPES=[('P',i) for i in range(1,7)]+[('C',i) for i in range(3,7)]
TYPES.sort(key=lambda z:(z[1],z[0]))
def multisets(rem,start=0):
 if rem==0:yield []
 for k in range(start,len(TYPES)):
  if TYPES[k][1]<=rem:
   for rest in multisets(rem-TYPES[k][1],k):yield [TYPES[k]]+rest

def graph(cs):
 missing=set();v=0
 for kind,n in cs:
  missing.update((v+i,v+i+1) for i in range(n-1))
  if kind=='C':missing.add((v,v+n-1))
  v+=n
 return [e for e in combinations(range(N),2) if e not in missing]

def skew(edges,signs):
 S=[[0]*N for _ in range(N)]
 for (i,j),s in zip(edges,signs):S[i][j],S[j][i]=s,-s
 return S

def nullbasis(S):
 A=[list(map(Fraction,r)) for r in S];piv=[];r=0
 for c in range(N):
  pos=next((i for i in range(r,N) if A[i][c]),None)
  if pos is None:continue
  A[r],A[pos]=A[pos],A[r];v=A[r][c];A[r]=[x/v for x in A[r]]
  for i in range(N):
   if i!=r and A[i][c]:
    v=A[i][c];A[i]=[a-v*b for a,b in zip(A[i],A[r])]
  piv.append(c);r+=1
 free=[c for c in range(N) if c not in piv]
 B=[]
 for f in free:
  b=[Fraction(0)]*N;b[f]=1
  for i,c in enumerate(piv):b[c]=-A[i][f]
  B.append(b)
 return B

def generic_injective(B):
 if not B:return False
 rows=list(zip(*B))
 if any(all(v==0 for v in r) for r in rows):return False
 return all(r!=s and r!=tuple(-v for v in s) for r,s in combinations(rows,2))

def integer_witness(S,B):
 import math, functools
 for t in range(1,1001):
  x=[sum(b[i]*t**j for j,b in enumerate(B)) for i in range(N)]
  if all(x) and len(set(map(abs,x)))==N:
   den=functools.reduce(math.lcm,(v.denominator for v in x),1)
   x=[int(v*den) for v in x];d=[1 if v>0 else -1 for v in x]
   S2=[[S[i][j]*d[i]*d[j] for j in range(N)] for i in range(N)]
   y=list(map(abs,x))
   assert all(sum(a*b for a,b in zip(r,y))==0 for r in S2)
   return {'S':S2,'labels':y}
 raise AssertionError('failed to choose generic vector')

def switching_test(edges):
 seen={0};tree=[]
 while len(seen)<N:
  e=next(e for e in edges if (e[0] in seen)!=(e[1] in seen))
  tree.append(e);seen.update(e)
 rest=[e for e in edges if e not in tree]
 count=Counter();witness=None
 for s in product((-1,1),repeat=len(rest)):
  S=skew(tree+rest,[1]*len(tree)+list(s));B=nullbasis(S)
  count['nullity_'+str(len(B))]+=1
  if generic_injective(B):
   count['injective_switching_classes']+=1
   if witness is None:witness=integer_witness(S,B)
 return dict(count),witness

# Positive, pairwise distinct labels on <=5 neighbors have at most one
# equal-sum partition up to complementation. Cache the partition by label set.
PART={}
def balance(vals):
 vals=tuple(sorted(vals))
 if vals not in PART:
  if sum(vals)%2:PART[vals]=None
  else:
   hits=[]
   for s in product((-1,1),repeat=len(vals)-1):
    signs=(1,)+s
    if sum(a*b for a,b in zip(vals,signs))==0:hits.append(dict(zip(vals,signs)))
   assert len(hits)<=1,(vals,hits)
   PART[vals]=hits[0] if hits else None
 return PART[vals]

def ddm_for_labels(edges,x):
 adj=[[j for j in range(N) if tuple(sorted((i,j))) in edges] for i in range(N)]
 base=[]
 for ns in adj:
  b=balance(x[j] for j in ns)
  if b is None:return None
  base.append({j:b[x[j]] for j in ns})
 eps={0:1};todo=[0]
 while todo:
  i=todo.pop()
  for j in adj[i]:
   v=-eps[i]*base[i][j]*base[j][i]
   if j in eps:
    if eps[j]!=v:return None
   else:eps[j]=v;todo.append(j)
 S=[[eps[i]*base[i].get(j,0) for j in range(N)] for i in range(N)]
 assert all(S[i][j]==-S[j][i] for i in range(N) for j in range(N))
 assert all(sum(a*b for a,b in zip(r,x))==0 for r in S)
 return S

def ddmo_test(edges,labels=range(1,7)):
 for x in permutations(labels):
  S=ddm_for_labels(edges,x)
  if S is not None:return {'S':S,'labels':x}
 return None

if __name__=='__main__':
 results=[]
 for cs in multisets(6):
  edges=graph(cs);name='+'.join(f'{kind}{n}' for kind,n in cs)
  count,w=switching_test(edges)
  d=ddmo_test(edges) if w else None
  r={'complement':name,'edges':edges,'num_edges':len(edges),'switching_counts':count,
     'injective_positive_kernel_witness':w,'DDMO_witness':d}
  results.append(r)
  print(name,len(edges),count,'injective=',bool(w),'DDMO=',bool(d),flush=True)
 with open(Path(__file__).with_suffix('.json'),'w') as f:json.dump(results,f,indent=2)
