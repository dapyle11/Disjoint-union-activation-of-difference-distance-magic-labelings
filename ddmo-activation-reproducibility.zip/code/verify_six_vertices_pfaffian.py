#!/usr/bin/env python3
"""Second independent verifier using all labeled graphs and Pfaffian cofactors.
This does not import the first verifier. The only rational-nullspace calls are
for rank-two matrices, using SymPy instead of the first verifier's elimination.
"""
from itertools import combinations,product
from collections import Counter
import json
from pathlib import Path
from sympy import Matrix
N=6;ALL=list(combinations(range(N),2))

def pf(A):
 n=len(A)
 if n==0:return 1
 return sum((-1)**(j+1)*A[0][j]*pf([[A[a][b] for b in range(n) if b not in (0,j)] for a in range(n) if a not in (0,j)]) for j in range(1,n))

def adjpf(S):
 C=[[0]*N for _ in range(N)]
 for i,j in ALL:
  keep=[a for a in range(N) if a not in (i,j)]
  C[i][j]=(-1)**(i+j)*pf([[S[a][b] for b in keep] for a in keep])
  C[j][i]=-C[i][j]
 return C

def obstruction(rows):
 for i,r in enumerate(rows):
  if not any(r):return {'zero_coordinate':i}
 for i,j in ALL:
  if rows[i]==rows[j]:return {'equal_coordinates':[i,j]}
  if rows[i]==[-v for v in rows[j]]:return {'opposite_coordinates':[i,j]}
 return None

classes={};labeled=0
for mask in range(1<<len(ALL)):
 edges=[e for k,e in enumerate(ALL) if mask>>k&1]
 if any(sum(i in e for e in edges)<3 for i in range(N)):continue
 labeled+=1;missing=[e for e in ALL if e not in edges]
 unseen=set(range(N));parts=[]
 while unseen:
  root=min(unseen);seen={root};q=[root]
  while q:
   u=q.pop()
   for a,b in missing:
    v=b if a==u else a if b==u else None
    if v is not None and v not in seen:seen.add(v);q.append(v)
  unseen-=seen
  deg=[sum(i in e for e in missing) for i in seen]
  parts.append(('C' if all(d==2 for d in deg) else 'P')+str(len(seen)))
 key='+'.join(sorted(parts,key=lambda z:(int(z[1:]),z[0])))
 if key not in classes:classes[key]=edges
assert len(classes)==19
out=[];certs=[]
for key,edges in sorted(classes.items()):
 tree=[];seen={0}
 while len(seen)<N:
  e=next(e for e in edges if (e[0] in seen)!=(e[1] in seen))
  tree.append(e);seen.update(e)
 rest=[e for e in edges if e not in tree];counts=Counter()
 for idx,signs in enumerate(product((-1,1),repeat=len(rest))):
  S=[[0]*N for _ in range(N)]
  for (i,j),s in list(zip(tree,[1]*len(tree)))+list(zip(rest,signs)):S[i][j],S[j][i]=s,-s
  p=pf(S)
  if p:
   counts['rank6']+=1;why={'pfaffian':p}
  else:
   C=adjpf(S)
   assert all(sum(S[i][k]*C[k][j] for k in range(N))==0 for i in range(N) for j in range(N))
   if any(map(any,C)):
    counts['rank4']+=1;why=obstruction(C)
   else:
    counts['rank2']+=1
    B=Matrix(S).nullspace();assert len(B)==4
    rows=[[b[i] for b in B] for i in range(N)]
    why=obstruction(rows)
   if why is None:counts['injective_switching_classes']+=1;why={'admissible':True}
  certs.append({'complement':key,'orientation_index':idx,'obstruction_or_admissible':why})
 out.append({'complement':key,'edges':edges,'tree_edges':tree,'chord_edges':rest,'counts':dict(counts)})
 print(key,dict(counts))
json.dump({'labeled_candidate_count':labeled,'classes':out,'certificates':certs},open(Path(__file__).with_suffix('.json'),'w'),indent=2)
print('TOTAL labeled candidate graphs',labeled,'unlabeled',len(classes),'switching classes',len(certs))
