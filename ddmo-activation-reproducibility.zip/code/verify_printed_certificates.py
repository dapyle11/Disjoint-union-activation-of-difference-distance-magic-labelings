#!/usr/bin/env python3
"""Check the certificates actually printed in main.tex and extension.tex.

Expected source fragments are checked before arithmetic, so a mathematical
certificate is not silently tested while a different one remains in the text.
Requires only Python's standard library. Writes its JSON result beside itself.
"""
from pathlib import Path
from itertools import product
import json

ROOT = Path(__file__).resolve().parent.parent
MAIN = (ROOT / 'main.tex').read_text()
EXTENSION = (ROOT / 'extension.tex').read_text()
CHECKS = []


def require(fragment, text=MAIN):
    assert fragment in text, f'Printed source changed: {fragment}'


def weights(labels, arcs):
    labels = list(labels)
    assert len(labels) == len(set(labels))
    assert len(arcs) == len(set(arcs))
    assert not any((v, u) in arcs for u, v in arcs)
    w = {v: 0 for v in labels}
    for u, v in arcs:
        w[u] -= v
        w[v] += u
    assert set(w.values()) == {0}, w
    return w


def bipartite(left, right):
    sign = (1, 1, -1)
    return [(u, v) if sign[i] * sign[j] == 1 else (v, u)
            for i, u in enumerate(left) for j, v in enumerate(right)]


require(r'(1,11,12)&(2,7,9)')
require(r'(3,5,8)&(4,6,10)')
a = bipartite((1, 11, 12), (2, 7, 9))
a += bipartite((3, 5, 8), (4, 6, 10))
CHECKS.append({'certificate': 'two K3,3 on [12]', 'weights': weights(range(1, 13), a)})
require(r'triples $(1,3,4)$ and $(2,5,7)$')
require(r'isolate label $6$')
CHECKS.append({'certificate': 'K3,3 plus one isolate', 'weights': weights(range(1, 8), bipartite((1, 3, 4), (2, 5, 7)))})

require(r'pairs $(1,4)$ and $(2,3)$, and its hub $5$')
a = [(5, 1), (5, 4), (2, 5), (3, 5)]
a += list(product((1, 4), (2, 3)))
CHECKS.append({'certificate': 'W4 on [5]', 'weights': weights(range(1, 6), a)})


def tripartite(signed_parts):
    assert all(sum(p) == 1 for p in signed_parts)
    arcs = []
    for i in range(3):
        for u, v in product(signed_parts[i], signed_parts[(i + 1) % 3]):
            arcs.append((abs(u), abs(v)) if u * v > 0 else (abs(v), abs(u)))
    return weights(range(1, 7), arcs)


require(r'parts $(1)$, $(4,3)$, $(6,2,5)$')
require(r'with signs $(+)$, $(+,-)$, $(-,+,+)$')
CHECKS.append({'certificate': 'K1,2,3 on [6]', 'weights': tripartite(((1,), (4, -3), (-6, 2, 5)))})
require(r'use $(2,1)$, $(4,3)$, $(6,5)$, each with signs $(+,-)$')
CHECKS.append({'certificate': 'K2,2,2 on [6]', 'weights': tripartite(((2, -1), (4, -3), (6, -5)))})

small = [((1, 3, -4), (2, 5, -7)),
         ((1, 2, -3), (4, -5, -6, 7)),
         ((1, 3, -4), (2, 5, -6, 7, -8)),
         ((1, -2, -3, 4), (5, -6, -7, 8)),
         ((1, -2, -3, 4), (-5, -6, -7, 8, 10)),
         ((-1, 2, -3, -4, 6), (-5, -7, -8, 9, 11))]
for left, right in small:
    fmt = lambda p: '(' + ','.join(map(str, p)) + ')'
    require(fmt((len(left), len(right))) + '&' + fmt(left) + '&' + fmt(right), EXTENSION)
    assert sum(left) == sum(right) == 0
    m = len(left) + len(right)
    labels = sorted(map(abs, left + right))
    target = list(range(1, m + 1)) if m % 4 in (0, 3) else list(range(1, m)) + [m + 1]
    assert labels == target
    arcs = [(abs(u), abs(v)) if u * v > 0 else (abs(v), abs(u)) for u, v in product(left, right)]
    CHECKS.append({'certificate': f'conditional boundary ({len(left)},{len(right)})', 'weights': weights(labels, arcs)})

report = {'status': 'PASS', 'source_fragments_matched': True, 'certificate_count': len(CHECKS), 'checks': CHECKS}
Path(__file__).with_name('printed_certificate_checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'PASS: {len(CHECKS)} printed certificates checked against source and exact vertex weights.')
