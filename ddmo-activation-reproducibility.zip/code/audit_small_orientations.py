#!/usr/bin/env python3
"""Independent exact-integer checks of small skew-adjacency matrices and 2K3,3.
No third-party dependencies. Convention S_ij=+1 means j->i.
"""
from itertools import product, combinations, permutations
from collections import Counter
import json
from pathlib import Path

def skew(n,edges,signs):
    S=[[0]*n for _ in range(n)]
    for (i,j),s in zip(edges,signs):
        S[i][j],S[j][i]=s,-s
    return S

def pf4(S,vs):
    a,b,c,d=vs
    return S[a][b]*S[c][d]-S[a][c]*S[b][d]+S[a][d]*S[b][c]

def cofactor5(S):
    return [(-1)**i*pf4(S,[j for j in range(5) if j!=i]) for i in range(5)]

def zero(S,x):
    return all(sum(a*b for a,b in zip(row,x))==0 for row in S)

def examine(name,n,removed):
    edges=[e for e in combinations(range(n),2) if e not in removed]
    counts=Counter(); pfvalues=set(); positive_vectors=set(); witness=None
    for signs in product((-1,1),repeat=len(edges)):
        S=skew(n,edges,signs); counts['orientations']+=1
        if n==4:
            p=pf4(S,range(4));pfvalues.add(p)
            counts['rank4' if p else 'rank_at_most2']+=1
        else:
            p=cofactor5(S)
            assert zero(S,p)
            pfvalues.update(p)
            if any(p):
                counts['rank4']+=1
                if all(v>0 for v in p) or all(v<0 for v in p):
                    counts['strictly_positive_kernel_ray']+=1
                    positive_vectors.add(tuple(abs(v) for v in p))
                    if len(set(p))==5: counts['positive_distinct_kernel_ray']+=1
            else: counts['rank_at_most2']+=1
            labels=[x for x in permutations(range(1,6)) if zero(S,x)]
            if labels:
                counts['DDM_orientations']+=1
                counts['DDM_orientation_labeling_pairs']+=len(labels)
                if witness is None: witness={'S':S,'labels':labels[0]}
    return {'graph':name,'counts':dict(counts),'principal_pfaffian_values':sorted(pfvalues),
            'positive_ray_patterns':sorted(positive_vectors),'DDM_witness':witness}

results=[examine('K4',4,set()),examine('K5',5,set()),
         examine('K5_minus_edge_01',5,{(0,1)}),
         examine('W4_K5_minus_edges_01_23',5,{(0,1),(2,3)})]
# Independently verify the 12-label construction as two complete bipartite graphs.
triples=[(1,11,12),(2,7,9),(3,5,8),(4,6,10)]
x=sum((list(t) for t in triples),[])
S=[[0]*12 for _ in range(12)]
s=(1,1,-1)
for base in (0,6):
    for i in range(3):
        for j in range(3):
            S[base+i][base+3+j]=s[i]*s[j]
            S[base+3+j][base+i]=-s[i]*s[j]
assert sorted(x)==list(range(1,13)) and zero(S,x)
results.append({'graph':'2K3,3','triples':triples,'label_vector':x,
                'signed_weight_vector':[sum(a*b for a,b in zip(r,x)) for r in S],
                'distinct_labels_1_to_12':sorted(x)==list(range(1,13))})
print(json.dumps(results,indent=2))
