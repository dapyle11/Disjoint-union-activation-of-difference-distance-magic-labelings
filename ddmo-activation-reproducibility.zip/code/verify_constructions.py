#!/usr/bin/env python3
"""Exact, dependency-free checks of classical pairings and DDMO certificates.

Constructions are credited to Skolem (1957), p. 58, and O'Keefe (1961),
pp. 80-81. This code does not prove an infinite theorem by testing.
The interval/difference arguments in main.tex supply the proof.
"""
from collections import Counter
from itertools import product
import json
from pathlib import Path


def skolem_pairs(n):
    """Classical Skolem pairing for n divisible by four."""
    assert n >= 4 and n % 4 == 0
    if n == 4:
        pairs = [(6, 7), (1, 3), (2, 5), (4, 8)]
    else:
        m = n // 4
        pairs = [(4*m+r, 8*m-r) for r in range(2*m)]
        pairs += [(2*m+1, 6*m), (2*m, 4*m-1)]
        pairs += [(r, 4*m-1-r) for r in range(1, m)]
        pairs += [(m, m+1)]
        pairs += [(m+2+r, 3*m-1-r) for r in range(m-2)]
    assert sorted(b-a for a, b in pairs) == list(range(1, n+1))
    assert sorted(x for p in pairs for x in p) == list(range(1, 2*n+1))
    return sorted(pairs, key=lambda ab: ab[1]-ab[0])


def hooked_pairs(n):
    """O'Keefe pairing for n == 2 mod 4, hole at position 2n."""
    assert n >= 2 and n % 4 == 2
    if n == 2:
        pairs = [(1, 2), (3, 5)]
    else:
        m = (n-2)//4
        pairs = [(r, 4*m+2-r) for r in range(1, 2*m+1)]
        pairs += [(2*m+1, 6*m+2), (4*m+2, 6*m+3), (4*m+3, 8*m+5)]
        pairs += [(4*m+3+r, 8*m+4-r) for r in range(1, m)]
        pairs += [(5*m+2+r, 7*m+3-r) for r in range(1, m)]
        pairs += [(7*m+3, 7*m+4)]
    assert sorted(b-a for a, b in pairs) == list(range(1, n+1))
    expected = list(range(1, 2*n)) + [2*n+1]
    assert sorted(x for p in pairs for x in p) == expected
    return sorted(pairs, key=lambda ab: ab[1]-ab[0])


def triples_from_pairs(n, pairs):
    triples = [(b-a, n+a, n+b) for a, b in pairs]
    assert all(a+b == c for a, b, c in triples)
    return triples


def orient_component(left, right):
    """Each triple is ordered (a,b,a+b); positive sign product points L->R."""
    signs = (1, 1, -1)
    return [(left[i], right[j]) if signs[i]*signs[j] == 1
            else (right[j], left[i])
            for i in range(3) for j in range(3)]


def verify_graph(k, r):
    assert k >= 1 and r >= 0 and (k % 2 == 0 or r >= 1)
    n = 2*k
    pairs = skolem_pairs(n) if k % 2 == 0 else hooked_pairs(n)
    triples = triples_from_pairs(n, pairs)
    arcs = []
    components = []
    for i in range(k):
        left, right = triples[2*i:2*i+2]
        components.append({"left": left, "right": right})
        arcs.extend(orient_component(left, right))
    used = {x for t in triples for x in t}
    isolates = sorted(set(range(1, 6*k+r+1))-used)
    assert len(isolates) == r
    assert len(arcs) == 9*k
    arcs_set = set(arcs)
    assert len(arcs_set) == len(arcs)
    assert not any((v,u) in arcs_set for u,v in arcs)
    weights = Counter({v:0 for v in range(1,6*k+r+1)})
    for u, v in arcs:
        weights[u] -= v
        weights[v] += u
    assert all(w == 0 for w in weights.values())
    return {"k":k, "r":r, "components":components, "isolates":isolates,
            "arcs":arcs, "weights":dict(weights)}


def count_orientations(left, right):
    count = 0
    for signs in product((-1,1), repeat=9):
        if all(sum(signs[3*i+j]*right[j] for j in range(3)) == 0
               for i in range(3)) and all(
                   sum(signs[3*i+j]*left[i] for i in range(3)) == 0
                   for j in range(3)):
            count += 1
    return count


def main():
    # Test every k, choosing the minimum number of isolates, through k=1000.
    for k in range(1,1001):
        verify_graph(k, k%2)
    # Extra isolates do not change existing vertex weights.
    for k in range(1,31):
        for r in range(k%2, k%2+6):
            verify_graph(k,r)
    assert count_orientations((1,11,12),(2,7,9)) == 2
    assert count_orientations((3,5,8),(4,6,10)) == 2
    assert count_orientations((1,2,3),(4,5,6)) == 0
    result = {
        "status":"PASS",
        "classical_constructions_checked":"k=1..1000; n=2k",
        "extra_isolates_checked":"k=1..30; six feasible r values each",
        "orientation_enumeration":"two valid Schur-pair examples have exactly 2; invalid example 0",
        "certificates":[verify_graph(1,1), verify_graph(2,0), verify_graph(3,1), verify_graph(4,0)]
    }
    path = Path(__file__).with_name("construction_checks.json")
    path.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="certificates"},indent=2))


if __name__ == "__main__":
    main()
