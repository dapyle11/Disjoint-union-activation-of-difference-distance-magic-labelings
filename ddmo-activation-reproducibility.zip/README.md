# Disjoint union activation of difference distance magic labelings

Version: 20 October 2026. Prepared for review, not submitted or published.

Human contributor: Daniel A. Pyle, Independent Researcher, ORCID
https://orcid.org/0009-0005-6456-1370

AI contribution: Lyra, an OpenAI-powered AI assistant, performed the literature
research, proof development, computation, and drafting. Daniel initiated and
directed the project. Lyra is an AI contributor, not a human author. Separate
AI-assisted audits are not human peer review or proof-assistant formalization.

## What is established

- The fixed-label complete-bipartite criterion is a signed-zero-sum criterion.
- A compatible fixed labeling of K3,3 has exactly two opposite orientations.
- For k >= 1 and r >= 0, k K3,3 plus r isolated vertices is DDMO exactly when
  k is even or r >= 1. This has a proof using explicit classical pairings.
- Twelve is the minimum order of a DDMO graph whose connected components are
  all non-DDMO in isolation. The lower bound is proved without computation.
- An exact exhaustive six-vertex computation, independently reproduced by two
  algorithms, makes 2 K3,3 the unique minimum example up to isomorphism.

The result is a short answer and refinement of the January 2026 disjoint-union
question, not a claim to new Skolem constructions. Novelty and priority are not
certified by the absence of a match in a literature search.

## Deliberately conditional extension

Section 6 derives a broader classification from the stated snowflake theorem
of Licona and Tey, arXiv:2411.12998v1, Theorem 4.17. It does not claim to
independently establish that theorem. The printed Lemma 3.17 in that source
has a parity inconsistency, illustrated in the manuscript. No counterexample
to Theorem 4.17 is asserted. The core results above do not depend on this
source or its older dependencies. The directly cited sources have free full
texts; this does not imply that every source they cite is freely readable.

## Files

- main.pdf: the rendered nine-page manuscript.
- main.tex and extension.tex: editable LaTeX source.
- code/: portable exact checkers.
- results/: recorded JSON outputs from the checkers.
- SHA256SUMS: file integrity manifest for this package.
- LICENSE-NOTICE.txt: manuscript license and separate software-license status.

Third-party source PDFs, private research records, build caches, format files,
font maps, and rendering intermediates are intentionally excluded.

## Build the manuscript

Use a normal TeX Live or MiKTeX installation with pdfLaTeX, Latin Modern,
amsmath, amssymb, amsthm, geometry, booktabs, microtype, xurl, and hyperref.
From the package root, run:

    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex

No bibliography program is needed. Keep extension.tex beside main.tex.

## Reproduce the exact checks

Python 3 is required. The principal classifier and every checker except the
independent Pfaffian verifier use only the Python standard library. The latter
requires SymPy; the verified environment used Python 3.12.14 and SymPy 1.14.0.
If needed, install SymPy into your own Python environment before that check.

From the package root, run:

    python3 code/verify_constructions.py
    python3 code/audit_small_orientations.py > code/audit_small_orientations.json
    python3 code/classify_six_vertices.py
    python3 code/verify_six_vertices_pfaffian.py
    python3 code/verify_printed_certificates.py
    python3 code/compare_recorded_results.py

The programs write generated JSON beside their own source files. The last
command compares all regenerated outputs with the recorded results/ copies
using parsed JSON equality, so whitespace differences are ignored.

Expected principal outcomes:

- Construction tests pass for every k from 1 through 1000, using the least
  required number of isolates, and for six feasible isolate counts at each
  k from 1 through 30.
- The six-vertex graph enumeration finds 1858 labeled minimum-degree-three
  graphs, 19 isomorphism types, and 3040 switching representatives.
- The rank counts are 2510 of rank six, 525 of rank four, and five of rank two.
  Exactly the five rank-two classes pass the full-kernel hyperplane test.
- The three compatible six-vertex graph types are K3,3, K1,2,3, and K2,2,2.
- Eleven printed certificates match the LaTeX source and have the required
  exact zero weights. This includes both tripartite examples and all six
  small boundary cases in the conditional section.

Finite construction tests check implementation consistency; the manuscript's
interval formulas and proofs establish the infinite statements. Six-vertex
uniqueness is explicitly computer assisted. No numerical optimizer or random
search is used to decide the finite classification.

## Sources and access

1. Aceska et al. (2026), Definition 2.1, Theorem 5.1, Section 6 p. 19:
   https://arxiv.org/pdf/2601.20492v1
2. Altman et al. (2024), Theorem 5 p. 4:
   https://d-nb.info/1355962609/34
3. Skolem (1957), Theorems 1 and 2 p. 57, construction p. 58:
   https://journals.msp.org/mscand/article/download/2833/2832/2864
4. O'Keefe (1961), theorem and construction pp. 80-81:
   https://journals.msp.org/mscand/article/download/2721/2720/2752
5. Licona and Tey (2024), Lemma 3.17 and Definition 4.1 p. 13,
   Theorem 4.17 p. 23:
   https://arxiv.org/pdf/2411.12998v1

Access was checked on 20 October 2026. These links are references, not copies
of the source documents. Attribution does not imply that their authors have
reviewed or endorsed this manuscript.
